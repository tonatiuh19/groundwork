GROUNDWORK CAPITAL GROUP · LOGO (high resolution rebuild, Oct 2026)

Rebuilt from the original 378x106 logo: the hexagon "G" mark is exact vector geometry; the wordmark is
set in Saira (free Google font, SIL Open Font License), matched to the original letter by letter.

COLORS
  Gold (mark, CAPITAL GROUP)   #C2923B   RGB 194 146 59
  Dark (GROUNDWORK)            #112321   RGB 17 35 33
  Navy background (brand)      #0E2A4A

FONTS
  GROUNDWORK      Saira Regular (400)
  CAPITAL GROUP   Saira Medium (500), wide letter spacing
  Download: https://fonts.google.com/specimen/Saira

WHICH FILE TO USE
  Website / email / social      png/groundwork-logo-color-1512px.png (transparent)
  Large print, signs, banners   pdf/groundwork-logo-color.pdf (vector) or png/...-3780px.png
  On dark or photo backgrounds  png/groundwork-logo-white-*.png (white text, gold mark)
  App icon, favicon, avatar     png/groundwork-mark-gold-1480px.png or svg/groundwork-mark-gold.svg
  Editing / designers           svg/*.svg  (the mark is pure vector; the wordmark is live text in Saira:
                                 install Saira first, or have the designer convert text to outlines)
